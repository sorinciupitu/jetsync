<?php
declare( strict_types=1 );

namespace JetSync\Runtime;

use JetSync\Registry\PostTypeRegistry;
use JetSync\Registry\TaxonomyRegistry;
use JetSync\Core\Logger;
use JetSync\Core\Capabilities;

/**
 * Handles WordPress runtime registration of post types and taxonomies.
 */
class RegistrationManager {
    private bool $caps_installed = false;

    /**
     * Constructor. Set up registries and hook into WordPress.
     *
     * @param PostTypeRegistry $cpt_registry Registry for CPTs.
     * @param TaxonomyRegistry $taxonomy_registry Registry for Taxonomies.
     * @param Logger|null $logger File logger instance.
     */
    public function __construct(
        private PostTypeRegistry $cpt_registry,
        private TaxonomyRegistry $taxonomy_registry,
        private ?Logger $logger = null
    ) {
        \add_action( 'init', [ $this, 'ensure_admin_caps' ], 99 );
        \add_action( 'admin_init', [ $this, 'ensure_admin_caps' ], 1 );
        \add_action( 'admin_init', [ $this, 'force_standard_caps_for_managed_post_types' ], 2 );
        \add_action( 'init', [ $this, 'register_structures' ], 11 );
        \add_action( 'registered_post_type', [ $this, 'maybe_patch_runtime_post_type_caps' ], 100, 2 );
        \add_filter( 'map_meta_cap', [ $this, 'map_meta_caps_for_managed_post_types' ], 1, 4 );
    }

    /**
     * Callback for 'init' action. Registers taxonomies first, then CPTs.
     *
     * @return void
     */
    public function register_structures() : void {
        $this->register_taxonomies();
        $this->register_post_types();
        $this->ensure_admin_caps();
    }

    public function ensure_admin_caps() : void {
        if ( $this->caps_installed ) {
            return;
        }

        if ( ! \function_exists( 'get_role' ) ) {
            return;
        }

        $role = \get_role( 'administrator' );
        if ( ! $role ) {
            return;
        }

        $did_add = false;

        $cpts = $this->cpt_registry->get_all();
        foreach ( $cpts as $cpt ) {
            if ( ! $cpt->is_active() ) {
                continue;
            }
            $args = $cpt->get_args();
            if ( empty( $args['capabilities'] ) || ! is_array( $args['capabilities'] ) ) {
                continue;
            }

            foreach ( $args['capabilities'] as $cap ) {
                if ( is_string( $cap ) && '' !== $cap ) {
                    if ( ! $role->has_cap( $cap ) ) {
                        $role->add_cap( $cap );
                        $did_add = true;
                    }
                }
            }
        }

        $runtime = \get_post_types( [ '_builtin' => false ], 'objects' );
        if ( is_array( $runtime ) ) {
            foreach ( $runtime as $obj ) {
                if ( ! is_object( $obj ) || ! isset( $obj->cap ) || ! is_object( $obj->cap ) ) {
                    continue;
                }
                foreach ( get_object_vars( $obj->cap ) as $cap ) {
                    if ( is_string( $cap ) && '' !== $cap ) {
                        if ( ! $role->has_cap( $cap ) ) {
                            $role->add_cap( $cap );
                            $did_add = true;
                        }
                    }
                }
            }
        }

        if ( is_array( $runtime ) && ! empty( $runtime ) ) {
            $this->caps_installed = true;
        }

        if ( $did_add ) {
            $this->caps_installed = true;
            if ( \function_exists( 'wp_get_current_user' ) ) {
                \wp_get_current_user()->get_role_caps();
            }
        }
    }

    /**
     * Registers all active Custom Post Types.
     *
     * @return void
     */
    private function register_post_types() : void {
        $cpts = $this->cpt_registry->get_all();

        foreach ( $cpts as $cpt ) {
            if ( ! $cpt->is_active() ) {
                continue;
            }

            $slug = $cpt->get_slug();

            // Collision guard: skip if already registered by JetEngine or theme
            if ( \post_type_exists( $slug ) ) {
                if ( $this->logger ) {
                    $this->logger->error(
                        sprintf( 'Post type collision detected: "%s" is already registered. Skipping.', $slug )
                    );
                }
                continue;
            }

            $args = $cpt->get_args();
            if ( ! \class_exists( 'Jet_Engine' ) && isset( $args['capabilities'] ) ) {
                unset( $args['capabilities'] );
                $args['capability_type'] = 'post';
                $args['map_meta_cap'] = true;
            }
            $result = \register_post_type( $slug, $args );

            if ( \is_wp_error( $result ) ) {
                if ( $this->logger ) {
                    $this->logger->error(
                        sprintf( 'Failed to register post type "%s": %s', $slug, $result->get_error_message() )
                    );
                }
            }
        }
    }

    public function maybe_patch_runtime_post_type_caps( string $post_type, $args ) : void {
        if ( \class_exists( 'Jet_Engine' ) ) {
            return;
        }

        if ( ! $this->is_managed_post_type( $post_type ) ) {
            return;
        }

        global $wp_post_types;
        if ( ! is_array( $wp_post_types ) || ! isset( $wp_post_types[ $post_type ] ) ) {
            return;
        }

        $post_obj = $wp_post_types[ $post_type ];
        $base = \get_post_type_object( 'post' );
        if ( ! $base || ! isset( $base->cap ) ) {
            return;
        }

        $post_obj->capability_type = 'post';
        $post_obj->cap = $base->cap;
        $post_obj->map_meta_cap = true;
        $wp_post_types[ $post_type ] = $post_obj;

        if ( \function_exists( 'wp_get_current_user' ) ) {
            \wp_get_current_user()->get_role_caps();
        }
    }

    public function force_standard_caps_for_managed_post_types() : void {
        if ( \class_exists( 'Jet_Engine' ) ) {
            return;
        }

        global $wp_post_types;
        if ( ! is_array( $wp_post_types ) ) {
            return;
        }

        $base = \get_post_type_object( 'post' );
        if ( ! $base || ! isset( $base->cap ) ) {
            return;
        }

        $cpts = $this->cpt_registry->get_all();
        foreach ( $cpts as $cpt ) {
            if ( ! $cpt->is_active() ) {
                continue;
            }

            $slug = $cpt->get_slug();
            if ( '' === $slug || ! isset( $wp_post_types[ $slug ] ) ) {
                continue;
            }

            $obj = $wp_post_types[ $slug ];
            $obj->capability_type = 'post';
            $obj->cap = $base->cap;
            $obj->map_meta_cap = true;
            $wp_post_types[ $slug ] = $obj;
        }

        if ( \function_exists( 'wp_get_current_user' ) ) {
            \wp_get_current_user()->get_role_caps();
        }
    }

    public function map_meta_caps_for_managed_post_types( array $caps, string $cap, int $user_id, array $args ) : array {
        if ( \class_exists( 'Jet_Engine' ) ) {
            return $caps;
        }

        if ( empty( $args[0] ) ) {
            return $caps;
        }

        $post_id = (int) $args[0];
        if ( $post_id <= 0 ) {
            return $caps;
        }

        $post_type = \get_post_type( $post_id );
        if ( ! is_string( $post_type ) || '' === $post_type ) {
            return $caps;
        }

        if ( ! $this->is_managed_post_type( $post_type ) ) {
            return $caps;
        }

        if ( ! \user_can( $user_id, Capabilities::MANAGE ) ) {
            return $caps;
        }

        if ( in_array( $cap, [ 'edit_post', 'delete_post', 'read_post' ], true ) ) {
            return [ Capabilities::MANAGE ];
        }

        return $caps;
    }

    private function is_managed_post_type( string $post_type ) : bool {
        $post_type = \sanitize_key( $post_type );
        if ( '' === $post_type ) {
            return false;
        }

        $cpts = $this->cpt_registry->get_all();
        foreach ( $cpts as $cpt ) {
            if ( $cpt->is_active() && $cpt->get_slug() === $post_type ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Registers all active Custom Taxonomies.
     *
     * @return void
     */
    private function register_taxonomies() : void {
        $taxonomies = $this->taxonomy_registry->get_all();

        foreach ( $taxonomies as $taxonomy ) {
            if ( ! $taxonomy->is_active() ) {
                continue;
            }

            $slug = $taxonomy->get_slug();

            // Collision guard: skip if already registered by JetEngine or theme
            if ( \taxonomy_exists( $slug ) ) {
                if ( $this->logger ) {
                    $this->logger->error(
                        sprintf( 'Taxonomy collision detected: "%s" is already registered. Skipping.', $slug )
                    );
                }
                continue;
            }

            $args = $taxonomy->get_args();
            $object_types = $taxonomy->get_object_types();

            $result = \register_taxonomy( $slug, $object_types, $args );

            if ( \is_wp_error( $result ) ) {
                if ( $this->logger ) {
                    $this->logger->error(
                        sprintf( 'Failed to register taxonomy "%s": %s', $slug, $result->get_error_message() )
                    );
                }
            }
        }
    }
}
