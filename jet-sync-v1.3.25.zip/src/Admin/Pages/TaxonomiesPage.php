<?php
declare( strict_types=1 );

namespace JetSync\Admin\Pages;

use JetSync\Core\JetSync;

/**
 * Custom Taxonomies Registry list page.
 */
class TaxonomiesPage extends BasePage {

    /**
     * {@inheritdoc}
     */
    public static function get_slug() : string {
        return 'jet-sync-taxonomies';
    }

    /**
     * {@inheritdoc}
     */
    public static function get_title() : string {
        return __( 'Custom Taxonomies', 'jet-sync' );
    }

    /**
     * Render Taxonomy list screen.
     *
     * @return void
     */
    public function render() : void {
        /** @var \JetSync\Registry\TaxonomyRegistry|null $taxonomy_registry */
        $taxonomy_registry = JetSync::get_instance()->get( 'taxonomy_registry' );
        $taxonomies = $taxonomy_registry ? $taxonomy_registry->get_all() : [];

        ?>
        <div class="wrap jetsync-wrap">
            <!-- Header Section -->
            <header class="jetsync-header">
                <div class="jetsync-header-logo">
                    <span class="jetsync-badge-version">v<?php echo esc_html( JETSYNC_VERSION ); ?></span>
                    <h1>JetSync</h1>
                </div>
            </header>

            <!-- Title & Actions bar -->
            <div class="jetsync-section-title">
                <h2><?php esc_html_e( 'Custom Taxonomies Registry', 'jet-sync' ); ?></h2>
                <button class="jetsync-btn primary-btn add-new-btn" disabled>
                    <span class="dashicons dashicons-plus"></span> <?php esc_html_e( 'Add New Taxonomy', 'jet-sync' ); ?>
                </button>
            </div>

            <!-- Table Container -->
            <div class="jetsync-workspace">
                <?php if ( empty( $taxonomies ) ) : ?>
                    <div class="registry-empty-state">
                        <span class="dashicons dashicons-category"></span>
                        <h3><?php esc_html_e( 'No Custom Taxonomies Defined', 'jet-sync' ); ?></h3>
                        <p><?php esc_html_e( 'You can define custom taxonomies inside JetSync or scan/import them from JetEngine using the wizard.', 'jet-sync' ); ?></p>
                        <a href="<?php echo esc_url( admin_url( 'admin.php?page=jet-sync-dashboard' ) ); ?>" class="jetsync-btn primary-btn">
                            <?php esc_html_e( 'Go to Dashboard', 'jet-sync' ); ?>
                        </a>
                    </div>
                <?php else : ?>
                    <table class="jetsync-table">
                        <thead>
                            <tr>
                                <th><?php esc_html_e( 'Name / Slug', 'jet-sync' ); ?></th>
                                <th><?php esc_html_e( 'Associated Types', 'jet-sync' ); ?></th>
                                <th><?php esc_html_e( 'Hierarchical', 'jet-sync' ); ?></th>
                                <th><?php esc_html_e( 'REST API', 'jet-sync' ); ?></th>
                                <th><?php esc_html_e( 'Status', 'jet-sync' ); ?></th>
                                <th><?php esc_html_e( 'Actions', 'jet-sync' ); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ( $taxonomies as $taxonomy ) :
                                $slug = $taxonomy->get_slug();
                                $labels = $taxonomy->get_labels();
                                $args = $taxonomy->get_args();
                                $object_types = $taxonomy->get_object_types();
                                $hierarchical = $args['hierarchical'] ?? true;
                                $show_in_rest = $args['show_in_rest'] ?? true;
                                $is_active = $taxonomy->is_active();
                                ?>
                                <tr>
                                    <td>
                                        <strong><?php echo esc_html( $labels['name'] ); ?></strong><br>
                                        <code><?php echo esc_html( $slug ); ?></code>
                                    </td>
                                    <td>
                                        <div class="tags-list">
                                            <?php if ( empty( $object_types ) ) : ?>
                                                <span class="tag tag-empty"><?php esc_html_e( 'None', 'jet-sync' ); ?></span>
                                            <?php else : ?>
                                                <?php foreach ( $object_types as $obj_type ) : ?>
                                                    <span class="tag object-tag"><?php echo esc_html( $obj_type ); ?></span>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td>
                                        <?php echo $hierarchical ? esc_html__( 'Yes (Hierarchical)', 'jet-sync' ) : esc_html__( 'No (Flat / Tags)', 'jet-sync' ); ?>
                                    </td>
                                    <td>
                                        <?php if ( $show_in_rest ) : ?>
                                            <span class="status-indicator active"><?php esc_html_e( 'Enabled', 'jet-sync' ); ?></span>
                                        <?php else : ?>
                                            <span class="status-indicator inactive"><?php esc_html_e( 'Disabled', 'jet-sync' ); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ( $is_active ) : ?>
                                            <span class="jetsync-status-badge active">
                                                <span class="pulse-dot"></span>
                                                <?php esc_html_e( 'Active', 'jet-sync' ); ?>
                                            </span>
                                        <?php else : ?>
                                            <span class="jetsync-status-badge inactive">
                                                <?php esc_html_e( 'Inactive', 'jet-sync' ); ?>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="table-actions">
                                        <button class="jetsync-btn secondary-btn edit-btn" data-slug="<?php echo esc_attr( $slug ); ?>" disabled>
                                            <?php esc_html_e( 'Edit', 'jet-sync' ); ?>
                                        </button>
                                        <button class="jetsync-btn danger-btn-outline delete-btn" data-slug="<?php echo esc_attr( $slug ); ?>" disabled>
                                            <?php esc_html_e( 'Delete', 'jet-sync' ); ?>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }
}
