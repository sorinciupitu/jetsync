<?php
declare( strict_types=1 );

namespace JetSync\Admin\Pages;

use JetSync\Core\JetSync;

/**
 * Custom Meta Boxes Registry list page.
 */
class MetaBoxesPage extends BasePage {

    /**
     * {@inheritdoc}
     */
    public static function get_slug() : string {
        return 'jet-sync-meta-boxes';
    }

    /**
     * {@inheritdoc}
     */
    public static function get_title() : string {
        return __( 'Meta Fields', 'jet-sync' );
    }

    /**
     * Render Meta Box list screen.
     *
     * @return void
     */
    public function render() : void {
        /** @var \JetSync\Registry\MetaBoxRegistry|null $metabox_registry */
        $metabox_registry = JetSync::get_instance()->get( 'metabox_registry' );
        $metaboxes = $metabox_registry ? $metabox_registry->get_all() : [];
        $is_add = isset( $_GET['action'] ) && 'add' === sanitize_key( (string) $_GET['action'] );
        $created = isset( $_GET['created'] ) ? (int) $_GET['created'] : -1;

        ?>
        <div class="wrap jetsync-wrap">
            <!-- Header Section -->
            <header class="jetsync-header">
                <div class="jetsync-header-logo">
                    <span class="jetsync-badge-version">v<?php echo esc_html( JETSYNC_VERSION ); ?></span>
                    <h1>JetSync</h1>
                </div>
            </header>

            <!-- Title & Actions bar -->
            <div class="jetsync-section-title">
                <h2><?php esc_html_e( 'Custom Meta Fields Registry', 'jet-sync' ); ?></h2>
                <a class="jetsync-btn primary-btn add-new-btn" href="<?php echo esc_url( admin_url( 'admin.php?page=jet-sync-meta-boxes&action=add' ) ); ?>">
                    <span class="dashicons dashicons-plus"></span> <?php esc_html_e( 'Add New Meta Box', 'jet-sync' ); ?>
                </a>
            </div>

            <!-- Table Container -->
            <div class="jetsync-workspace">
                <?php if ( 0 === $created ) : ?>
                    <div class="scan-status-alert warning" style="margin-bottom:1.5rem;">
                        <span class="dashicons dashicons-warning"></span>
                        <div><strong><?php esc_html_e( 'Meta box was not created.', 'jet-sync' ); ?></strong> <?php esc_html_e( 'Please check required fields and try again.', 'jet-sync' ); ?></div>
                    </div>
                <?php elseif ( 1 === $created ) : ?>
                    <div class="scan-status-alert info" style="background: rgba(16, 185, 129, 0.08); border-color: rgba(16, 185, 129, 0.2); color: #a7f3d0; margin-bottom:1.5rem;">
                        <span class="dashicons dashicons-yes-alt" style="color:var(--success);"></span>
                        <div><strong><?php esc_html_e( 'Meta box created.', 'jet-sync' ); ?></strong></div>
                    </div>
                <?php endif; ?>

                <?php if ( $is_add ) : ?>
                    <div style="max-width: 900px;">
                        <h3 style="margin-top:0;"><?php esc_html_e( 'Add New Meta Box', 'jet-sync' ); ?></h3>
                        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                            <?php wp_nonce_field( 'jetsync_add_metabox' ); ?>
                            <input type="hidden" name="action" value="jetsync_add_metabox">

                            <table class="form-table" role="presentation">
                                <tr>
                                    <th scope="row"><label for="jetsync_mb_title"><?php esc_html_e( 'Title', 'jet-sync' ); ?></label></th>
                                    <td><input name="title" type="text" id="jetsync_mb_title" value="" class="regular-text" required></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="jetsync_mb_id"><?php esc_html_e( 'ID (slug)', 'jet-sync' ); ?></label></th>
                                    <td><input name="id" type="text" id="jetsync_mb_id" value="" class="regular-text" required></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="jetsync_mb_object_types"><?php esc_html_e( 'Post Types (comma separated)', 'jet-sync' ); ?></label></th>
                                    <td><input name="object_types" type="text" id="jetsync_mb_object_types" value="" class="regular-text" placeholder="news,women,men"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="jetsync_mb_fields"><?php esc_html_e( 'Fields', 'jet-sync' ); ?></label></th>
                                    <td>
                                        <textarea name="fields" id="jetsync_mb_fields" rows="10" class="large-text" placeholder="meta_key|Label|text"></textarea>
                                        <p class="description"><?php esc_html_e( 'One field per line. Format: meta_key|Label|type. Type can be: text, textarea, select, radio, checkbox, switcher, wysiwyg, date.', 'jet-sync' ); ?></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php esc_html_e( 'Active', 'jet-sync' ); ?></th>
                                    <td><label><input name="active" type="checkbox" value="1" checked> <?php esc_html_e( 'Enabled', 'jet-sync' ); ?></label></td>
                                </tr>
                            </table>

                            <p class="submit">
                                <button type="submit" class="jetsync-btn primary-btn"><?php esc_html_e( 'Create Meta Box', 'jet-sync' ); ?></button>
                                <a href="<?php echo esc_url( admin_url( 'admin.php?page=jet-sync-meta-boxes' ) ); ?>" class="jetsync-btn secondary-btn" style="margin-left:0.5rem;"><?php esc_html_e( 'Cancel', 'jet-sync' ); ?></a>
                            </p>
                        </form>
                    </div>
                <?php else : ?>
                <?php if ( empty( $metaboxes ) ) : ?>
                    <div class="registry-empty-state">
                        <span class="dashicons dashicons-edit-page"></span>
                        <h3><?php esc_html_e( 'No Meta Boxes Defined', 'jet-sync' ); ?></h3>
                        <p><?php esc_html_e( 'You can define custom meta fields groups inside JetSync or scan/import them from JetEngine using the wizard.', 'jet-sync' ); ?></p>
                        <a href="<?php echo esc_url( admin_url( 'admin.php?page=jet-sync-dashboard' ) ); ?>" class="jetsync-btn primary-btn">
                            <?php esc_html_e( 'Go to Dashboard', 'jet-sync' ); ?>
                        </a>
                    </div>
                <?php else : ?>
                    <table class="jetsync-table">
                        <thead>
                            <tr>
                                <th><?php esc_html_e( 'Name / ID', 'jet-sync' ); ?></th>
                                <th><?php esc_html_e( 'Targeted Post Types', 'jet-sync' ); ?></th>
                                <th><?php esc_html_e( 'Fields Count', 'jet-sync' ); ?></th>
                                <th><?php esc_html_e( 'Fields List', 'jet-sync' ); ?></th>
                                <th><?php esc_html_e( 'Status', 'jet-sync' ); ?></th>
                                <th><?php esc_html_e( 'Actions', 'jet-sync' ); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ( $metaboxes as $mb ) :
                                $id = $mb->get_id();
                                $title = $mb->get_title();
                                $object_types = $mb->get_object_types();
                                $fields = $mb->get_fields();
                                $is_active = $mb->is_active();
                                ?>
                                <tr>
                                    <td>
                                        <strong><?php echo esc_html( $title ); ?></strong><br>
                                        <code><?php echo esc_html( $id ); ?></code>
                                    </td>
                                    <td>
                                        <div class="tags-list">
                                            <?php if ( empty( $object_types ) ) : ?>
                                                <span class="tag tag-empty"><?php esc_html_e( 'All Post Types', 'jet-sync' ); ?></span>
                                            <?php else : ?>
                                                <?php foreach ( $object_types as $obj_type ) : ?>
                                                    <span class="tag object-tag"><?php echo esc_html( $obj_type ); ?></span>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td>
                                        <?php echo count( $fields ); ?>
                                    </td>
                                    <td>
                                        <div style="max-height: 120px; overflow-y: auto; padding-right: 0.5rem;">
                                            <?php foreach ( $fields as $f ) : ?>
                                                <div style="font-size: 0.85rem; margin-bottom: 0.35rem; line-height: 1.4;">
                                                    <code><?php echo esc_html( $f->get_name() ); ?></code>
                                                    <span style="color: var(--text-muted); font-size: 0.8rem;">(<?php echo esc_html( $f->get_type() ); ?>)</span>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if ( $is_active ) : ?>
                                            <span class="jetsync-status-badge active">
                                                <span class="pulse-dot"></span>
                                                <?php esc_html_e( 'Active', 'jet-sync' ); ?>
                                            </span>
                                        <?php else : ?>
                                            <span class="jetsync-status-badge inactive">
                                                <?php esc_html_e( 'Inactive', 'jet-sync' ); ?>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="table-actions">
                                        <button class="jetsync-btn secondary-btn edit-btn" data-id="<?php echo esc_attr( $id ); ?>" disabled>
                                            <?php esc_html_e( 'Edit', 'jet-sync' ); ?>
                                        </button>
                                        <button class="jetsync-btn danger-btn-outline delete-btn" data-id="<?php echo esc_attr( $id ); ?>" disabled>
                                            <?php esc_html_e( 'Delete', 'jet-sync' ); ?>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }
}
