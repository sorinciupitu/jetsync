<?php
declare( strict_types=1 );

namespace JetSync\Admin\Pages;

use JetSync\Core\JetSync;

/**
 * Custom Post Types Registry list page.
 */
class CptsPage extends BasePage {

    /**
     * {@inheritdoc}
     */
    public static function get_slug() : string {
        return 'jet-sync-cpts';
    }

    /**
     * {@inheritdoc}
     */
    public static function get_title() : string {
        return __( 'Custom Post Types', 'jet-sync' );
    }

    /**
     * Render CPT list screen.
     *
     * @return void
     */
    public function render() : void {
        /** @var \JetSync\Registry\PostTypeRegistry|null $cpt_registry */
        $cpt_registry = JetSync::get_instance()->get( 'cpt_registry' );
        $cpts = $cpt_registry ? $cpt_registry->get_all() : [];

        ?>
        <div class="wrap jetsync-wrap">
            <!-- Header Section -->
            <header class="jetsync-header">
                <div class="jetsync-header-logo">
                    <span class="jetsync-badge-version">v<?php echo esc_html( JETSYNC_VERSION ); ?></span>
                    <h1>JetSync</h1>
                </div>
            </header>

            <!-- Title & Actions bar -->
            <div class="jetsync-section-title">
                <h2><?php esc_html_e( 'Custom Post Types Registry', 'jet-sync' ); ?></h2>
                <button class="jetsync-btn primary-btn add-new-btn" disabled>
                    <span class="dashicons dashicons-plus"></span> <?php esc_html_e( 'Add New Post Type', 'jet-sync' ); ?>
                </button>
            </div>

            <!-- Table Container -->
            <div class="jetsync-workspace">
                <?php if ( empty( $cpts ) ) : ?>
                    <div class="registry-empty-state">
                        <span class="dashicons dashicons-admin-post"></span>
                        <h3><?php esc_html_e( 'No Custom Post Types Defined', 'jet-sync' ); ?></h3>
                        <p><?php esc_html_e( 'You can define post types inside JetSync or scan/import them from JetEngine using the wizard.', 'jet-sync' ); ?></p>
                        <a href="<?php echo esc_url( admin_url( 'admin.php?page=jet-sync-dashboard' ) ); ?>" class="jetsync-btn primary-btn">
                            <?php esc_html_e( 'Go to Dashboard', 'jet-sync' ); ?>
                        </a>
                    </div>
                <?php else : ?>
                    <table class="jetsync-table">
                        <thead>
                            <tr>
                                <th><?php esc_html_e( 'Name / Slug', 'jet-sync' ); ?></th>
                                <th><?php esc_html_e( 'Labels', 'jet-sync' ); ?></th>
                                <th><?php esc_html_e( 'Supports', 'jet-sync' ); ?></th>
                                <th><?php esc_html_e( 'REST API', 'jet-sync' ); ?></th>
                                <th><?php esc_html_e( 'Status', 'jet-sync' ); ?></th>
                                <th><?php esc_html_e( 'Actions', 'jet-sync' ); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ( $cpts as $cpt ) :
                                $slug = $cpt->get_slug();
                                $labels = $cpt->get_labels();
                                $args = $cpt->get_args();
                                $supports = $args['supports'] ?? [];
                                $show_in_rest = $args['show_in_rest'] ?? true;
                                $is_active = $cpt->is_active();
                                ?>
                                <tr>
                                    <td>
                                        <strong><?php echo esc_html( $labels['name'] ); ?></strong><br>
                                        <code><?php echo esc_html( $slug ); ?></code>
                                    </td>
                                    <td>
                                        <span class="meta-label"><?php esc_html_e( 'Singular:', 'jet-sync' ); ?></span> <?php echo esc_html( $labels['singular_name'] ); ?>
                                    </td>
                                    <td>
                                        <div class="tags-list">
                                            <?php foreach ( $supports as $support ) : ?>
                                                <span class="tag"><?php echo esc_html( $support ); ?></span>
                                            <?php endforeach; ?>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if ( $show_in_rest ) : ?>
                                            <span class="status-indicator active"><?php esc_html_e( 'Enabled', 'jet-sync' ); ?></span>
                                        <?php else : ?>
                                            <span class="status-indicator inactive"><?php esc_html_e( 'Disabled', 'jet-sync' ); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ( $is_active ) : ?>
                                            <span class="jetsync-status-badge active">
                                                <span class="pulse-dot"></span>
                                                <?php esc_html_e( 'Active', 'jet-sync' ); ?>
                                            </span>
                                        <?php else : ?>
                                            <span class="jetsync-status-badge inactive">
                                                <?php esc_html_e( 'Inactive', 'jet-sync' ); ?>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="table-actions">
                                        <button class="jetsync-btn secondary-btn edit-btn" data-slug="<?php echo esc_attr( $slug ); ?>" disabled>
                                            <?php esc_html_e( 'Edit', 'jet-sync' ); ?>
                                        </button>
                                        <button class="jetsync-btn danger-btn-outline delete-btn" data-slug="<?php echo esc_attr( $slug ); ?>" disabled>
                                            <?php esc_html_e( 'Delete', 'jet-sync' ); ?>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }
}
