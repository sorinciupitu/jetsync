<?php
declare( strict_types=1 );

namespace JetSync\Admin;

use JetSync\Core\JetSync;
use JetSync\Core\Capabilities;
use JetSync\Admin\Pages\DashboardPage;
use JetSync\Admin\Pages\CptsPage;
use JetSync\Admin\Pages\TaxonomiesPage;
use JetSync\Admin\Pages\MetaBoxesPage;
use JetSync\Admin\Pages\RelationsPage;
use JetSync\Admin\Pages\ListingsPage;
use JetSync\Admin\Pages\QueriesPage;
use JetSync\Admin\Pages\MigrationPage;
use JetSync\Registry\Model\MetaBoxDefinition;
use JetSync\Registry\Model\MetaFieldDefinition;
use JetSync\Registry\Model\RelationDefinition;
use JetSync\Registry\Model\ListingDefinition;
use JetSync\Registry\Model\QueryDefinition;

/**
 * Main Controller for WP Admin screens and menus.
 */
class AdminController {

    /**
     * JetSync main instance.
     *
     * @var JetSync
     */
    private $plugin;

    /**
     * Constructor. Registers admin hooks.
     *
     * @param JetSync $plugin The main JetSync singleton instance.
     */
    public function __construct( JetSync $plugin ) {
        $this->plugin = $plugin;

        add_action( 'admin_menu', [ $this, 'register_menu' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
        add_action( 'admin_post_jetsync_export_config', [ $this, 'handle_export_download' ] );
        add_action( 'admin_post_jetsync_add_relation', [ $this, 'handle_add_relation' ] );
        add_action( 'admin_post_jetsync_update_relation', [ $this, 'handle_update_relation' ] );
        add_action( 'admin_post_jetsync_add_metabox', [ $this, 'handle_add_metabox' ] );
        add_action( 'admin_post_jetsync_add_listing', [ $this, 'handle_add_listing' ] );
        add_action( 'admin_post_jetsync_delete_listing', [ $this, 'handle_delete_listing' ] );
        add_action( 'admin_post_jetsync_add_query', [ $this, 'handle_add_query' ] );
        add_action( 'admin_post_jetsync_delete_query', [ $this, 'handle_delete_query' ] );
    }

    /**
     * Register JetSync menu and its submenus in WordPress.
     *
     * @return void
     */
    public function register_menu() : void {
        // Main JetSync page
        add_menu_page(
            __( 'JetSync', 'jet-sync' ),
            __( 'JetSync', 'jet-sync' ),
            Capabilities::MANAGE,
            'jet-sync-dashboard',
            [ $this, 'render_dashboard' ],
            'dashicons-randomize',
            25
        );

        // Standardise submenus
        add_submenu_page(
            'jet-sync-dashboard',
            __( 'Dashboard', 'jet-sync' ),
            __( 'Dashboard', 'jet-sync' ),
            Capabilities::MANAGE,
            'jet-sync-dashboard',
            [ $this, 'render_dashboard' ]
        );

        // Active screens for Stage 2 & 4
        add_submenu_page(
            'jet-sync-dashboard',
            __( 'Custom Post Types', 'jet-sync' ),
            __( 'Custom Post Types', 'jet-sync' ),
            Capabilities::MANAGE,
            CptsPage::get_slug(),
            [ $this, 'render_cpts_page' ]
        );

        add_submenu_page(
            'jet-sync-dashboard',
            __( 'Taxonomies', 'jet-sync' ),
            __( 'Taxonomies', 'jet-sync' ),
            Capabilities::MANAGE,
            TaxonomiesPage::get_slug(),
            [ $this, 'render_taxonomies_page' ]
        );

        add_submenu_page(
            'jet-sync-dashboard',
            __( 'Meta Fields', 'jet-sync' ),
            __( 'Meta Fields', 'jet-sync' ),
            Capabilities::MANAGE,
            MetaBoxesPage::get_slug(),
            [ $this, 'render_metaboxes_page' ]
        );

        // Stage 5: Relations Registry
        add_submenu_page(
            'jet-sync-dashboard',
            __( 'Relations', 'jet-sync' ),
            __( 'Relations', 'jet-sync' ),
            Capabilities::MANAGE,
            RelationsPage::get_slug(),
            [ $this, 'render_relations_page' ]
        );

        // Stage 6: Migration Center
        add_submenu_page(
            'jet-sync-dashboard',
            __( 'Migration Wizard', 'jet-sync' ),
            __( 'Migration Wizard', 'jet-sync' ),
            Capabilities::MIGRATE,
            MigrationPage::get_slug(),
            [ $this, 'render_migration_page' ]
        );

        add_submenu_page(
            'jet-sync-dashboard',
            __( 'Listings', 'jet-sync' ),
            __( 'Listings', 'jet-sync' ),
            Capabilities::MANAGE,
            ListingsPage::get_slug(),
            [ $this, 'render_listings_page' ]
        );

        add_submenu_page(
            'jet-sync-dashboard',
            __( 'Queries', 'jet-sync' ),
            __( 'Queries', 'jet-sync' ),
            Capabilities::MANAGE,
            QueriesPage::get_slug(),
            [ $this, 'render_queries_page' ]
        );
    }

    /**
     * Render the Dashboard page.
     *
     * @return void
     */
    public function render_dashboard() : void {
        $page = new DashboardPage();
        $page->render();
    }

    /**
     * Render the CPT list page.
     *
     * @return void
     */
    public function render_cpts_page() : void {
        $page = new CptsPage();
        $page->render();
    }

    /**
     * Render the Taxonomies list page.
     *
     * @return void
     */
    public function render_taxonomies_page() : void {
        $page = new TaxonomiesPage();
        $page->render();
    }

    /**
     * Render the Meta Boxes list page.
     *
     * @return void
     */
    public function render_metaboxes_page() : void {
        $page = new MetaBoxesPage();
        $page->render();
    }

    /**
     * Render the Relations Registry page.
     *
     * @return void
     */
    public function render_relations_page() : void {
        $page = new RelationsPage();
        $page->render();
    }

    /**
     * Render the Migration Center page.
     *
     * @return void
     */
    public function render_migration_page() : void {
        $page = new MigrationPage();
        $page->render();
    }

    public function render_listings_page() : void {
        $page = new ListingsPage();
        $page->render();
    }

    public function render_queries_page() : void {
        $page = new QueriesPage();
        $page->render();
    }

    /**
     * Handle config export download via admin-post.php.
     *
     * @return void
     */
    public function handle_export_download() : void {
        if ( ! current_user_can( Capabilities::MANAGE ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'jet-sync' ), 403 );
        }

        check_admin_referer( 'jetsync_export' );

        $export = new \JetSync\Migration\ExportManager();
        $export->serve_download();
    }

    public function handle_add_relation() : void {
        if ( ! current_user_can( Capabilities::MANAGE ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'jet-sync' ), 403 );
        }

        check_admin_referer( 'jetsync_add_relation' );

        $id = isset( $_POST['id'] ) ? sanitize_key( (string) $_POST['id'] ) : '';
        $title = isset( $_POST['title'] ) ? sanitize_text_field( (string) $_POST['title'] ) : '';
        $parent_object = isset( $_POST['parent_object'] ) ? sanitize_key( (string) $_POST['parent_object'] ) : 'post';
        $child_object = isset( $_POST['child_object'] ) ? sanitize_key( (string) $_POST['child_object'] ) : 'post';
        $type = isset( $_POST['type'] ) ? sanitize_key( (string) $_POST['type'] ) : 'many_to_many';
        $active = isset( $_POST['active'] ) ? (bool) $_POST['active'] : true;

        if ( '' === $id || '' === $title ) {
            wp_safe_redirect( admin_url( 'admin.php?page=jet-sync-relations&created=0' ) );
            exit;
        }

        /** @var \JetSync\Registry\RelationRegistry|null $relation_registry */
        $relation_registry = $this->plugin->get( 'relation_registry' );
        if ( ! $relation_registry ) {
            wp_safe_redirect( admin_url( 'admin.php?page=jet-sync-relations&created=0' ) );
            exit;
        }

        $relation_registry->add(
            new RelationDefinition(
                id: $id,
                title: $title,
                parent_object: $parent_object,
                child_object: $child_object,
                type: $type,
                active: $active
            )
        );
        $relation_registry->save();

        wp_safe_redirect( admin_url( 'admin.php?page=jet-sync-relations&created=1' ) );
        exit;
    }

    public function handle_update_relation() : void {
        if ( ! current_user_can( Capabilities::MANAGE ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'jet-sync' ), 403 );
        }

        check_admin_referer( 'jetsync_update_relation' );

        $id = isset( $_POST['id'] ) ? sanitize_key( (string) $_POST['id'] ) : '';
        $title = isset( $_POST['title'] ) ? sanitize_text_field( (string) $_POST['title'] ) : '';
        $parent_object = isset( $_POST['parent_object'] ) ? sanitize_key( (string) $_POST['parent_object'] ) : 'post';
        $child_object = isset( $_POST['child_object'] ) ? sanitize_key( (string) $_POST['child_object'] ) : 'post';
        $type = isset( $_POST['type'] ) ? sanitize_key( (string) $_POST['type'] ) : 'many_to_many';
        $active = isset( $_POST['active'] ) ? (bool) $_POST['active'] : false;

        if ( '' === $id || '' === $title ) {
            wp_safe_redirect( admin_url( 'admin.php?page=jet-sync-relations&updated=0' ) );
            exit;
        }

        /** @var \JetSync\Registry\RelationRegistry|null $relation_registry */
        $relation_registry = $this->plugin->get( 'relation_registry' );
        if ( ! $relation_registry ) {
            wp_safe_redirect( admin_url( 'admin.php?page=jet-sync-relations&updated=0' ) );
            exit;
        }

        $existing = $relation_registry->get( $id );
        if ( ! $existing ) {
            wp_safe_redirect( admin_url( 'admin.php?page=jet-sync-relations&updated=0' ) );
            exit;
        }

        $relation_registry->add(
            new RelationDefinition(
                id: $id,
                title: $title,
                parent_object: $parent_object,
                child_object: $child_object,
                type: $type,
                active: $active
            )
        );
        $relation_registry->save();

        wp_safe_redirect( admin_url( 'admin.php?page=jet-sync-relations&updated=1' ) );
        exit;
    }

    public function handle_add_metabox() : void {
        if ( ! current_user_can( Capabilities::MANAGE ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'jet-sync' ), 403 );
        }

        check_admin_referer( 'jetsync_add_metabox' );

        $id = isset( $_POST['id'] ) ? sanitize_key( (string) $_POST['id'] ) : '';
        $title = isset( $_POST['title'] ) ? sanitize_text_field( (string) $_POST['title'] ) : '';
        $object_types_raw = isset( $_POST['object_types'] ) ? sanitize_text_field( (string) $_POST['object_types'] ) : '';
        $fields_raw = isset( $_POST['fields'] ) ? (string) $_POST['fields'] : '';
        $active = isset( $_POST['active'] ) ? (bool) $_POST['active'] : true;

        if ( '' === $id || '' === $title ) {
            wp_safe_redirect( admin_url( 'admin.php?page=jet-sync-meta-boxes&created=0' ) );
            exit;
        }

        /** @var \JetSync\Registry\MetaBoxRegistry|null $metabox_registry */
        $metabox_registry = $this->plugin->get( 'metabox_registry' );
        if ( ! $metabox_registry ) {
            wp_safe_redirect( admin_url( 'admin.php?page=jet-sync-meta-boxes&created=0' ) );
            exit;
        }

        $object_types = [];
        if ( '' !== $object_types_raw ) {
            foreach ( preg_split( '/\s*,\s*/', $object_types_raw ) as $slug ) {
                $slug = sanitize_key( (string) $slug );
                if ( '' !== $slug ) {
                    $object_types[] = $slug;
                }
            }
        }

        $allowed_field_types = [
            'text',
            'textarea',
            'select',
            'radio',
            'checkbox',
            'switcher',
            'wysiwyg',
            'date',
        ];

        $field_objects = [];
        foreach ( preg_split( "/\r\n|\n|\r/", $fields_raw ) as $line ) {
            $line = trim( (string) $line );
            if ( '' === $line ) {
                continue;
            }

            $parts = array_map( 'trim', explode( '|', $line ) );
            $name = isset( $parts[0] ) ? sanitize_key( (string) $parts[0] ) : '';
            if ( '' === $name ) {
                continue;
            }

            $field_title = isset( $parts[1] ) && '' !== $parts[1] ? sanitize_text_field( (string) $parts[1] ) : ucwords( str_replace( [ '_', '-' ], ' ', $name ) );
            $type = isset( $parts[2] ) ? sanitize_key( (string) $parts[2] ) : 'text';
            if ( ! in_array( $type, $allowed_field_types, true ) ) {
                $type = 'text';
            }

            $field_objects[] = new MetaFieldDefinition(
                name: $name,
                title: $field_title,
                type: $type
            );
        }

        $metabox_registry->add(
            new MetaBoxDefinition(
                id: $id,
                title: $title,
                object_types: $object_types,
                context: 'normal',
                priority: 'default',
                fields: $field_objects,
                active: $active
            )
        );
        $metabox_registry->save();

        wp_safe_redirect( admin_url( 'admin.php?page=jet-sync-meta-boxes&created=1' ) );
        exit;
    }

    public function handle_add_listing() : void {
        if ( ! current_user_can( Capabilities::MANAGE ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'jet-sync' ), 403 );
        }

        check_admin_referer( 'jetsync_add_listing' );

        $id = isset( $_POST['id'] ) ? sanitize_key( (string) $_POST['id'] ) : '';
        $title = isset( $_POST['title'] ) ? sanitize_text_field( (string) $_POST['title'] ) : '';
        $post_type = isset( $_POST['post_type'] ) ? sanitize_key( (string) $_POST['post_type'] ) : '';
        $ppp = isset( $_POST['posts_per_page'] ) ? (int) $_POST['posts_per_page'] : 10;
        $orderby = isset( $_POST['orderby'] ) ? sanitize_key( (string) $_POST['orderby'] ) : 'date';
        $order = isset( $_POST['order'] ) ? sanitize_key( (string) $_POST['order'] ) : 'DESC';
        $selected_fields = [];
        if ( isset( $_POST['selected_fields'] ) && is_array( $_POST['selected_fields'] ) ) {
            $selected_fields = array_values( array_map( 'sanitize_text_field', array_map( 'strval', $_POST['selected_fields'] ) ) );
        }
        $template = isset( $_POST['template'] ) ? wp_kses_post( (string) $_POST['template'] ) : '';
        $active = isset( $_POST['active'] ) ? (bool) $_POST['active'] : true;

        if ( '' === $id || '' === $title || '' === $post_type ) {
            wp_safe_redirect( admin_url( 'admin.php?page=jet-sync-listings&created=0' ) );
            exit;
        }

        /** @var \JetSync\Registry\ListingRegistry|null $listing_registry */
        $listing_registry = $this->plugin->get( 'listing_registry' );
        if ( ! $listing_registry ) {
            wp_safe_redirect( admin_url( 'admin.php?page=jet-sync-listings&created=0' ) );
            exit;
        }

        $listing_registry->add(
            new ListingDefinition(
                id: $id,
                title: $title,
                post_type: $post_type,
                posts_per_page: $ppp,
                orderby: $orderby,
                order: $order,
                selected_fields: $selected_fields,
                template: $template,
                active: $active
            )
        );
        $listing_registry->save();

        wp_safe_redirect( admin_url( 'admin.php?page=jet-sync-listings&created=1' ) );
        exit;
    }

    public function handle_delete_listing() : void {
        if ( ! current_user_can( Capabilities::MANAGE ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'jet-sync' ), 403 );
        }

        $id = isset( $_GET['id'] ) ? sanitize_key( (string) $_GET['id'] ) : '';
        if ( '' === $id ) {
            wp_safe_redirect( admin_url( 'admin.php?page=jet-sync-listings&deleted=0' ) );
            exit;
        }

        check_admin_referer( 'jetsync_delete_listing_' . $id );

        /** @var \JetSync\Registry\ListingRegistry|null $listing_registry */
        $listing_registry = $this->plugin->get( 'listing_registry' );
        if ( ! $listing_registry ) {
            wp_safe_redirect( admin_url( 'admin.php?page=jet-sync-listings&deleted=0' ) );
            exit;
        }

        $listing_registry->delete( $id );
        wp_safe_redirect( admin_url( 'admin.php?page=jet-sync-listings&deleted=1' ) );
        exit;
    }

    public function handle_add_query() : void {
        if ( ! current_user_can( Capabilities::MANAGE ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'jet-sync' ), 403 );
        }

        check_admin_referer( 'jetsync_add_query' );

        $id = isset( $_POST['id'] ) ? sanitize_key( (string) $_POST['id'] ) : '';
        $title = isset( $_POST['title'] ) ? sanitize_text_field( (string) $_POST['title'] ) : '';
        $relation_id = isset( $_POST['relation_id'] ) ? sanitize_key( (string) $_POST['relation_id'] ) : '';
        $target_post_type = isset( $_POST['target_post_type'] ) ? sanitize_key( (string) $_POST['target_post_type'] ) : '';
        $source_post_types_raw = isset( $_POST['source_post_types'] ) ? sanitize_text_field( (string) $_POST['source_post_types'] ) : '';
        $posts_per_page = isset( $_POST['posts_per_page'] ) ? (int) $_POST['posts_per_page'] : 10;
        $orderby = isset( $_POST['orderby'] ) ? sanitize_key( (string) $_POST['orderby'] ) : 'date';
        $order = isset( $_POST['order'] ) ? sanitize_key( (string) $_POST['order'] ) : 'DESC';
        $active = isset( $_POST['active'] ) ? (bool) $_POST['active'] : true;

        if ( '' === $id || '' === $title || '' === $relation_id || '' === $target_post_type ) {
            wp_safe_redirect( admin_url( 'admin.php?page=jet-sync-queries&created=0' ) );
            exit;
        }

        $source_post_types = [];
        if ( '' !== $source_post_types_raw ) {
            foreach ( preg_split( '/\s*,\s*/', $source_post_types_raw ) as $post_type ) {
                $post_type = sanitize_key( (string) $post_type );
                if ( '' !== $post_type ) {
                    $source_post_types[] = $post_type;
                }
            }
        }

        /** @var \JetSync\Registry\QueryRegistry|null $query_registry */
        $query_registry = $this->plugin->get( 'query_registry' );
        if ( ! $query_registry ) {
            wp_safe_redirect( admin_url( 'admin.php?page=jet-sync-queries&created=0' ) );
            exit;
        }

        $query_registry->add(
            new QueryDefinition(
                id: $id,
                title: $title,
                relation_id: $relation_id,
                target_post_type: $target_post_type,
                source_post_types: $source_post_types,
                posts_per_page: $posts_per_page,
                orderby: $orderby,
                order: $order,
                active: $active
            )
        );
        $query_registry->save();

        wp_safe_redirect( admin_url( 'admin.php?page=jet-sync-queries&created=1' ) );
        exit;
    }

    public function handle_delete_query() : void {
        if ( ! current_user_can( Capabilities::MANAGE ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'jet-sync' ), 403 );
        }

        $id = isset( $_GET['id'] ) ? sanitize_key( (string) $_GET['id'] ) : '';
        if ( '' === $id ) {
            wp_safe_redirect( admin_url( 'admin.php?page=jet-sync-queries&deleted=0' ) );
            exit;
        }

        check_admin_referer( 'jetsync_delete_query_' . $id );

        /** @var \JetSync\Registry\QueryRegistry|null $query_registry */
        $query_registry = $this->plugin->get( 'query_registry' );
        if ( ! $query_registry ) {
            wp_safe_redirect( admin_url( 'admin.php?page=jet-sync-queries&deleted=0' ) );
            exit;
        }

        $query_registry->delete( $id );
        wp_safe_redirect( admin_url( 'admin.php?page=jet-sync-queries&deleted=1' ) );
        exit;
    }

    /**
     * Render placeholder page for future modules.
     *
     * @return void
     */
    public function render_placeholder_page() : void {
        $page_title = __( 'JetSync Page', 'jet-sync' );
        if ( isset( $_GET['page'] ) ) {
            $slug = sanitize_text_field( $_GET['page'] );
            switch ( $slug ) {
                case 'jet-sync-relations':
                    $page_title = __( 'Relations Registry', 'jet-sync' );
                    break;
                case 'jet-sync-listings':
                    $page_title = __( 'Listings Builder', 'jet-sync' );
                    break;
                case 'jet-sync-queries':
                    $page_title = __( 'Elementor Queries', 'jet-sync' );
                    break;
                case 'jet-sync-migration':
                    $page_title = __( 'Migration Wizard', 'jet-sync' );
                    break;
            }
        }
        ?>
        <div class="wrap jetsync-wrap">
            <header class="jetsync-header">
                <div class="jetsync-header-logo">
                    <span class="jetsync-badge-version">v<?php echo esc_html( JETSYNC_VERSION ); ?></span>
                    <h1>JetSync</h1>
                </div>
            </header>
            <div class="jetsync-workspace" style="padding: 3.5rem 2rem; text-align: center; max-width: 800px; margin: 2rem auto; border-radius: 12px; background: rgba(255, 255, 255, 0.05); backdrop-filter: blur(10px); border: 1px solid rgba(255, 255, 255, 0.1);">
                <span class="dashicons dashicons-lock" style="font-size: 4rem; width: 4rem; height: 4rem; color: #64748b; margin-bottom: 1.5rem;"></span>
                <h2 style="font-size: 1.75rem; font-weight: 600; margin-bottom: 0.75rem; color: #f8fafc;"><?php echo esc_html( $page_title ); ?></h2>
                <p style="font-size: 1.05rem; line-height: 1.6; color: #94a3b8; max-width: 500px; margin: 0 auto 2rem;">
                    <?php esc_html_e( 'This section is currently locked. It will be enabled in the upcoming stage of the JetSync installation roadmap.', 'jet-sync' ); ?>
                </p>
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=jet-sync-dashboard' ) ); ?>" class="jetsync-btn primary-btn">
                    <?php esc_html_e( 'Back to Dashboard', 'jet-sync' ); ?>
                </a>
            </div>
        </div>
        <?php
    }

    /**
     * Enqueue CSS/JS only on JetSync specific pages.
     *
     * @param string $hook The current admin page hook.
     * @return void
     */
    public function enqueue_assets( string $hook ) : void {
        if ( false === strpos( $hook, 'jet-sync' ) ) {
            return;
        }

        wp_enqueue_style(
            'jet-sync-admin-css',
            JETSYNC_URL . 'assets/css/admin.css',
            [],
            JETSYNC_VERSION
        );

        wp_enqueue_script(
            'jet-sync-admin-js',
            JETSYNC_URL . 'assets/js/admin.js',
            [ 'jquery' ],
            JETSYNC_VERSION,
            true
        );
    }
}
